create database SIMSETopicoUCV;
go
GRANT SELECT ON dbo.Usuario TO elvis;
use SIMSETopicoUCV;

create table Usuario
(
id int primary key IDENTITY(1,1),
codigo varchar(50) not null,
contrasena varchar(70)
);


-- Tabla ProductoFarmaceutico
CREATE TABLE ProductoFarmaceutico (
    codigo VARCHAR(50) PRIMARY KEY,
    nombre VARCHAR(255) NOT NULL,
    precio float NOT NULL,
    stock INT NOT NULL,
    fechaVencimiento DATE,
    idProveedor INT,
    FOREIGN KEY (idProveedor) REFERENCES Proveedor(idProveedor)
);

-- Tabla Proveedor
CREATE TABLE Proveedor (
    idProveedor INT PRIMARY KEY IDENTITY(1,1),
     nif varchar(50),
    telefono varchar(50),
    tipo_producto varchar(60),
   encargado varchar(40)
);

-- Tabla InventarioProductos
CREATE TABLE InventarioProductos (
    codigo VARCHAR(50) PRIMARY KEY,
    nombre VARCHAR(255) NOT NULL,
    precio FLOAT NOT NULL,
    stock INT NOT NULL,
    fechaVencimiento DATE,
    idProveedor INT,
    FOREIGN KEY (idProveedor) REFERENCES Proveedor(idProveedor)
);

-- Tabla Persona
CREATE TABLE Persona (
    idPersona INT PRIMARY KEY IDENTITY(1,1),
    nombre VARCHAR(255),
    apellido VARCHAR(255),
    edad INT
);

-- Tabla Alumno
CREATE TABLE Alumno (
    idAlumno INT PRIMARY KEY IDENTITY(1,1),
    codigoAlumno VARCHAR(50),
    carrera VARCHAR(255),

    idPersona INT,
    FOREIGN KEY (idPersona) REFERENCES Persona(idPersona)
);

ALTER TABLE Alumno
ADD ciclo VARCHAR(40);
select * from Alumno

-- Tabla Enfermera
CREATE TABLE Enfermera (
    idEnfermera INT PRIMARY KEY IDENTITY(1,1),
    especialidad VARCHAR(255),
    idPersona INT,
    FOREIGN KEY (idPersona) REFERENCES Persona(idPersona)
);
ALTER TABLE Enfermera
ADD idAlumno INT,
FOREIGN KEY (idAlumno) REFERENCES Alumno(idAlumno);
SELECT * FROM Alumno;

select * from Enfermera
-- Tabla Sesion
CREATE TABLE Sesion (
    idSesion INT PRIMARY KEY IDENTITY(1,1),
    idAlumno INT,
    fechaInicio DATETIME,
    fechaFin DATETIME,
    FOREIGN KEY (idAlumno) REFERENCES Alumno(idAlumno)
);

ALTER TABLE Sesion
    ALTER COLUMN fechaInicio DATETIME NOT NULL;
	ALTER TABLE Sesion
    ALTER COLUMN fechaFin DATETIME NOT NULL;
	ALTER TABLE Sesion

	-- Inserci�n de un nuevo registro con fecha y hora espec�ficas
INSERT INTO Sesion (idAlumno, fechaInicio, fechaFin, disponible)
VALUES (1, '2024-06-02 12:00:00', '2024-06-02 14:00:00', 1);


-- Tabla Traslado
CREATE TABLE Traslado (
    idTraslado INT PRIMARY KEY IDENTITY(1,1),
    idAlumno INT,
    idEnfermera INT,
    fechaInicio DATETIME,
    fechaFin DATETIME,
    FOREIGN KEY (idAlumno) REFERENCES Alumno(idAlumno),
    FOREIGN KEY (idEnfermera) REFERENCES Enfermera(idEnfermera)
);

-- Tabla Reporte
CREATE TABLE Reporte (
    idReporte INT PRIMARY KEY IDENTITY(1,1),
    idAlumno INT,
    idEnfermera INT,
    fecha DATE,
    descripcion TEXT,
    FOREIGN KEY (idAlumno) REFERENCES Alumno(idAlumno),
    FOREIGN KEY (idEnfermera) REFERENCES Enfermera(idEnfermera)
);

-- Tabla EstadoSalud
CREATE TABLE EstadoSalud (
    idEstadoSalud INT PRIMARY KEY IDENTITY(1,1),
    idAlumno INT,
    fecha DATE,
    descripcion TEXT,
    FOREIGN KEY (idAlumno) REFERENCES Alumno(idAlumno)
);
select * from EstadoSalud
-- Insertar datos en la tabla Proveedor
INSERT INTO Proveedor (nif,telefono,tipo_producto,encargado) VALUES
('1234567890', '987654321', 'Medicamentos','Elvis Vega'),
('0987654321', '123456789', 'Equipos M�dicos','Luis Angel');

-- Insertar datos en la tabla Persona
INSERT INTO Persona (nombre, apellido, edad) VALUES
('Juan', 'Perez', 30),
('Maria', 'Gomez', 25),
('Carlos', 'Lopez', 35);

-- Insertar datos en la tabla Alumno
INSERT INTO Alumno (codigoAlumno, carrera, idPersona) VALUES
('A001', 'Medicina', 1),
('A002', 'Enfermer�a', 2);


UPDATE Alumno
SET ciclo = '6'
WHERE codigoAlumno = 'A001';

UPDATE Alumno
SET ciclo = '9'
WHERE codigoAlumno = 'A002';

-- Insertar datos en la tabla Enfermera
INSERT INTO Enfermera (especialidad, idPersona,idAlumno) VALUES
('Pediatr�a',1,1);

-- Insertar datos en la tabla ProductoFarmaceutico
INSERT INTO ProductoFarmaceutico (codigo, nombre, precio, stock, fechaVencimiento, idProveedor) VALUES
('PF001', 'Paracetamol', 0.5, 100, '2025-12-31', 1),
('PF002', 'Ibuprofeno', 1.0, 200, '2024-06-30', 2);

-- Insertar datos en la tabla InventarioProductos
INSERT INTO InventarioProductos (codigo, nombre, precio, stock, fechaVencimiento, idProveedor) VALUES
('IP001', 'Aspirina', 0.3, 150, '2023-09-30', 1),
('IP002', 'Antibi�tico', 2.5, 50, '2024-11-15', 2);

-- Insertar datos en la tabla Usuario
INSERT INTO Usuario (codigo, contrasena) VALUES
('user1', 'password1'),
('user2', 'password2');

-- Insertar datos en la tabla Sesion
INSERT INTO Sesion (idAlumno, fechaInicio, fechaFin) VALUES
(1, '2024-05-24 10:00:00', '2024-05-24 12:00:00'),
(2, '2024-05-25 11:00:00', '2024-05-25 13:00:00');

-- Insertar datos en la tabla Traslado
INSERT INTO Traslado (idAlumno, idEnfermera, fechaInicio, fechaFin) VALUES
(1, 1, '2024-05-24 10:00:00', '2024-05-24 12:00:00'),
(2, 1, '2024-05-25 11:00:00', '2024-05-25 13:00:00');

-- Insertar datos en la tabla Reporte
INSERT INTO Reporte (idAlumno, idEnfermera, fecha, descripcion) VALUES
(1, 1, '2024-05-24', 'Reporte de salud del alumno 1'),
(2, 1, '2024-05-25', 'Reporte de salud del alumno 2');

-- Insertar datos en la tabla EstadoSalud
INSERT INTO EstadoSalud (idAlumno, fecha, descripcion) VALUES
(1, '2024-05-24', 'Estado de salud del alumno 1'),
(2, '2024-05-25', 'Estado de salud del alumno 2');

-- Seleccionar todos los registros de la tabla Proveedor
SELECT * FROM Proveedor;

-- Seleccionar todos los registros de la tabla Persona
SELECT * FROM Persona;

-- Seleccionar todos los registros de la tabla Alumno
SELECT * FROM Alumno;

-- Seleccionar todos los registros de la tabla Enfermera
SELECT * FROM Enfermera;

-- Seleccionar todos los registros de la tabla ProductoFarmaceutico
SELECT * FROM ProductoFarmaceutico;

-- Seleccionar todos los registros de la tabla InventarioProductos
SELECT * FROM InventarioProductos;

-- Seleccionar todos los registros de la tabla Usuario
SELECT * FROM Usuario;

-- Seleccionar todos los registros de la tabla Sesion
SELECT * FROM Sesion;

-- Seleccionar todos los registros de la tabla Traslado
SELECT * FROM Traslado;

-- Seleccionar todos los registros de la tabla Reporte
SELECT * FROM Reporte;

-- Seleccionar todos los registros de la tabla EstadoSalud
SELECT * FROM EstadoSalud;

-- Eliminar registros referenciados en InventarioProductos
DELETE FROM InventarioProductos WHERE idProveedor = @idProveedor;

-- Ahora puedes eliminar el registro en Proveedor
DELETE FROM Proveedor WHERE idProveedor = @idProveedor;

-- Eliminar la restricci�n de clave for�nea actual
ALTER TABLE InventarioProductos
DROP CONSTRAINT FK__Inventari__idPro__0A688BB1;

-- Crear la clave for�nea con eliminaci�n en cascada
ALTER TABLE InventarioProductos
ADD CONSTRAINT FK__Inventari__idPro__0A688BB1
FOREIGN KEY (idProveedor)
REFERENCES Proveedor(idProveedor)
ON DELETE CASCADE;

ALTER TABLE Sesion
DROP CONSTRAINT FK__Sesion__idAlumno__70A8B9AE;

ALTER TABLE Sesion
ADD CONSTRAINT FK__Sesion__idAlumno__70A8B9AE
FOREIGN KEY (idAlumno)
REFERENCES Alumno(idAlumno)
ON DELETE CASCADE;



SELECT  a.codigoAlumno,a.idAlumno, a.carrera, a.ciclo, 
                       p.nombre, p.apellido, p.edad, 
                       s.fechaInicio, s.fechaFin 
                       FROM EstadoSalud es 
                       INNER JOIN Alumno a ON es.idAlumno = a.idAlumno 
                       INNER JOIN Persona p ON a.idPersona = p.idPersona 
                       INNER JOIN Sesion s ON s.idAlumno = a.idAlumno;